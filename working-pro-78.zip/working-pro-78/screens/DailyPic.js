import React, { Component } from 'react';
import {
  Text,
  View,
  StyleSheet,
  TouchableOpacity,
  ImageBackground,
  Image,
  Alert,
  Platform,
  StatusBar,
  SafeAreaView,
  Dimensions,
  Linking,
} from 'react-native';
import axios from 'axios';

export default class DailyPicScreen extends Component {
  constructor() {
    super();
    this.state = {
      apod: {},
    };
  }
  getAPOD = () => {
    axios
      .get(
        'https://api.nasa.gov/neo/rest/v1/feed?api_key=qP6ZzSP9y2o7uxgVeuHzzwErJfsMcmbmnfeRRYLg'
      )
      .then((response) => {
        this.setState({ apod: response.data });
      })
      .catch((error) => {
        Alert.alert(error.message);
      });
  };
  render() {
    return (
      <View style={{ flex: 1 }}>
        <SafeAreaView
          style={{
            marginTop: Platform.OS === 'android' ? StatusBar.currentHeight : 0,
          }}
        />
        <ImageBackground
          source={require('../assets/space.gif')}
          style={{
            flex: 1,
            resizeMode: 'cover',
            width: Dimensions.get('window').width,
            height: Dimensions.get('window').height,
          }}>
          <Text
            style={{
              fontSize: 20,
              fontWeight: 'bold',
              color: 'white',
              marginTop: 75,
              paddingLeft: 30,
            }}>
            Astronomy picture of the day
          </Text>
          <Text
            style={{
              fontSize: 40,
              fontWeight: 'bold',
              color: 'white',
            }}>
            {this.state.apod.title}
          </Text>
          <TouchableOpacity
            style={{
              backgroundColor: 'rgba(52, 52, 52, 0.5)',
              justifyContent: 'center',
              marginLeft: 10,
              marginRight: 10,
              marginTop: 5,
              borderRadius: 10,
              padding: 10,
            }}
            onPress={() =>
              Linking.openURL(this.state.apod.url).catch((error) =>
                console.error("Couldn't load page", error)
              )
            }>
            <View
              style={{
                flex: 0.2,
                backgroundColor: 'white',
                marginTop: -10,
                borderTopLeftRadius: 30,
                borderTopRightRadius: 30,
                borderBottomLeftRadius: 30,
                borderBottomRightRadius: 30,
                padding: 10,
              }}>
              <Image
                source={require('../assets/play-video.png')}
                style={{ width: 50, height: 50 }}
              />
            </View>
          </TouchableOpacity>
          <Text
            style={{
              fontSize: 30,
              fontWeight: 'bold',
              color: 'black',
            }}>
            {this.state.apod.explanation}
          </Text>
        </ImageBackground>
      </View>
    );
  }
}
